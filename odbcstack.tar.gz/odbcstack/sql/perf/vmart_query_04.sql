-- IN predicate
-- Find all products supplied by stores in MA

SELECT  /*+LABEL(q04_${store_state}) */
DISTINCT s.product_key, p.product_description
FROM store.store_sales_fact s, public.product_dimension p
WHERE s.product_key = p.product_key
AND s.product_version = p.product_version
AND s.store_key IN (
  SELECT store_key
  FROM store.store_dimension
  WHERE store_state = '${store_state}')
ORDER BY s.product_key;
