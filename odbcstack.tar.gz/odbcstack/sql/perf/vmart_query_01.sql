-- FROM clause subquery
-- Return the values for five products with the 
-- lowest-fat content in the Dairy department

SELECT /*+LABEL(q01_$blabel_$ftag_${department_description})*/ 
  fat_content 
FROM (
  SELECT DISTINCT fat_content 
  FROM product_dimension 
  WHERE department_description 
  IN ('${department_description}') 
) AS food 
ORDER BY fat_content
LIMIT 5;
